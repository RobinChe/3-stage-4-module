package com.lagou.edu.controller;

import com.lagou.edu.common.response.RespResult;
import com.lagou.edu.remoteClient.EmailFeignClient;
import com.lagou.edu.service.AuthCodeService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/code")
public class AuthCodeController {

    @Autowired
    private AuthCodeService authCodeService;

    @Autowired
    private EmailFeignClient emailFeignClient;

    /**
     * 生成并发送验证码到邮箱
     * @param email
     * @return
     */
    @GetMapping("/create/{email}")
    public RespResult generateAndSendCode(@PathVariable("email") String email) {
        //TODO 生成6位随机数字验证码并保存到数据库中
        //TODO 调用邮件服务发送验证码
        String code = authCodeService.generateEmailCode();
        Long id = authCodeService.saveAuthCode(email, code);
        if(id != null) {
            emailFeignClient.sendEmail(email, code);
        }
        return RespResult.buildRespSuccess();
    }


    /**
     * 验证验证码
     * @param email
     * @param code
     * @return 0：正确  1：错误  2：超时
     */
    @GetMapping("/validate/{email}/{code}")
    public RespResult validateCode(@PathVariable("email") String email, @PathVariable("code") String code) {
        RespResult respResult = new RespResult();
        if(StringUtils.isBlank(email) || StringUtils.isBlank(code)) {
            respResult.setCode(201);
            respResult.setMessage("缺少参数");
            return respResult;//错误y
        }
        //2.验证code
        boolean isExist = authCodeService.checkAuthCodeExist(email, code);
        if(isExist)
            return RespResult.buildRespSuccess();
        else {
            respResult.setCode(401);
            respResult.setMessage("验证码有误或验证码无效");
            return respResult;
        }

    }

}
