package com.lagou.edu.service.impl;

import com.lagou.edu.dao.AuthCodeRepository;
import com.lagou.edu.entity.AuthCode;
import com.lagou.edu.service.AuthCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Random;


@Service
public class AuthCodeServiceImpl implements AuthCodeService {

    private static final Long EMAIL_CODE_MAX_EXPIRE_TIME = 10 * 60 * 1000L;

    @Autowired
    private AuthCodeRepository authCodeRepository;


    @Override
    public boolean checkAuthCodeExist(String email, String code) {
        int count = authCodeRepository.findCodeIsExist(email, code);
        if(count > 0)
            return true;
        return false;
    }

    @Override
    public String generateEmailCode() {
        String code = "";
        for (int i = 0; i < 6; i++) {
            code += new Random().nextInt(10);
        }
        return code;
    }

    public static void main(String[] args) {
        String code = "";
        for (int i = 0; i < 6; i++) {
            code += new Random().nextInt(10);
        }
        System.out.println(code);
    }


    @Override
    public Long saveAuthCode(String email, String code) {
        AuthCode authCode = new AuthCode();
        authCode.setEmail(email);
        authCode.setCode(code);
        Date currentDate = new Date();
        authCode.setCreateTime(currentDate);
        authCode.setExpireTime(new Date(currentDate.getTime() + EMAIL_CODE_MAX_EXPIRE_TIME));
        authCodeRepository.save(authCode);
        return authCode.getId();
    }
}
