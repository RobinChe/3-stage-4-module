package com.lagou.edu.test;

import com.lagou.edu.LagouServiceCodeApplication8081;
import com.lagou.edu.common.response.RespResult;
import com.lagou.edu.remoteClient.EmailFeignClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = LagouServiceCodeApplication8081.class)
public class EmailFeignClientTest {

    @Autowired
    private EmailFeignClient emailFeignClient;

    @Test
        public void sendEmailTest() {
        RespResult respResult = emailFeignClient.sendEmail("949285946@qq.com", "123456");
        System.out.println("response is :" + respResult.getCode() + "-" + respResult.getMessage());
    }
}
