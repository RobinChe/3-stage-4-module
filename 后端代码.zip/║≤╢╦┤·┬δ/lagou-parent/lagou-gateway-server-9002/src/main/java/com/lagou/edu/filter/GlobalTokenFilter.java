package com.lagou.edu.filter;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;


@Slf4j
@Component
public class GlobalTokenFilter implements GlobalFilter, Ordered {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();
        String uri = request.getURI().toString();
        log.info("enter GlobalTokenFilter.....");

        //检查是否忽略cookie的请求
        boolean isIgnoreCookies = checkIgnoreCokiesPath(uri);
        if(isIgnoreCookies) {
            return chain.filter(exchange);
        }

        MultiValueMap<String, HttpCookie> multiValueMap = request.getCookies();

        log.debug("multiValueMap size is:{}", multiValueMap.size());
        if(multiValueMap != null && multiValueMap.size() > 0) {
            multiValueMap.forEach((key, value) -> log.debug("multiValueMap key:{}, value:{}", key, value));
        }

        List<HttpCookie> cookies = multiValueMap.get("token");
        if(cookies != null && cookies.size() != 0) {
            String token = cookies.get(0).getValue();
            //token 为空，说明未登录
            if(StringUtils.isBlank(token)) {
                response.setStatusCode(HttpStatus.FORBIDDEN);
                return response.setComplete();
            }

            //放行
            log.info("get request token is: {}", token);
            return chain.filter(exchange);
        }

        //没有cookie，不放行
        response.setStatusCode(HttpStatus.FORBIDDEN);
        return response.setComplete();
    }



    private boolean checkIgnoreCokiesPath(String uri) {
        List<String> ignoreCokiesList = new ArrayList<>();
        ignoreCokiesList.add("/user/register");
        ignoreCokiesList.add("/user/login");
        ignoreCokiesList.add("/code/create");

        ignoreCokiesList.add("/user/info");

        for (String ignorePath : ignoreCokiesList) {
            if(uri.contains(ignorePath))
                return true;
        }
        return false;

    }

    @Override
    public int getOrder() {
        return 0;
    }
}
