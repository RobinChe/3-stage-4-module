package com.lagou.edu.service;

import com.lagou.edu.entity.Token;

public interface UserService {

    Long saveUser(Token token);

    Boolean checkExist(String email);

    Token findUserByEmail(String email);

    Token findUserByToken(String token);

    String generateToken(String email, String password, String salt);

}
