package com.lagou.edu.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "lagou_token")
public class Token {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String email;
    private String token;
    private String salt;

}
