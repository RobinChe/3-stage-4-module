package com.lagou.edu.service.impl;

import com.lagou.edu.dao.UserRepository;
import com.lagou.edu.entity.Token;
import com.lagou.edu.service.UserService;
import com.lagou.edu.utils.MD5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public Long saveUser(Token token) {
        token = userRepository.save(token);
        return token.getId();
    }

    @Override
    public Boolean checkExist(String email) {
        Token token = new Token();
        token.setEmail(email);
        Example<Token> example = Example.of(token);
        Long count = userRepository.count(example);
        if (count > 0L)
            return true;
        return false;
    }

    @Override
    public Token findUserByEmail(String email) {
        Token token = userRepository.findByEmail(email);
        return token;
    }

    @Override
    public Token findUserByToken(String reqToken) {
        Token token = new Token();
        token.setToken(reqToken);
        Example<Token> example = Example.of(token);
        Optional<Token> optional = userRepository.findOne(example);
        if (optional.isPresent())
            return optional.get();
        return null;
    }

    @Override
    public String generateToken(String email, String password, String salt) {
        try {
            return MD5.getMD5(email + "," + password + "," + salt);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
