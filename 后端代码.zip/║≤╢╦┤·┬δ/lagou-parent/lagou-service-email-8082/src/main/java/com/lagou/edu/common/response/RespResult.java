package com.lagou.edu.common.response;

import lombok.Data;

@Data
public class RespResult<T> {
    private int code;
    private String message;
    private T data;

    public static RespResult buildRespSuccess() {
        RespResult respResult = new RespResult();
        respResult.setCode(0);
        respResult.setMessage("success");
        return respResult;
    }
}
