package com.lagou.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer //声明本项目是一个eureka服务
public class LagouEurekaServerApplication8761 {

    public static void main(String[] args) {
        SpringApplication.run(LagouEurekaServerApplication8761.class, args);
    }
}
