package com.lagou.edu.utils;

import java.security.InvalidKeyException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class DES {
    private static final String DESKEY = "*$Skylar&*($SAAST%**):";
    
    private SecretKey key;

    private Cipher cipherEnc;
    
    private Cipher cipherDec;

    public DES() {
        byte[] rawKeyData = DESKEY.getBytes();
        try {
            DESKeySpec dks = new DESKeySpec(rawKeyData);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            key = keyFactory.generateSecret(dks);
            
            cipherEnc = Cipher.getInstance("DES");
            SecureRandom randEnc = new SecureRandom();
            cipherEnc.init(Cipher.ENCRYPT_MODE, key, randEnc);

            cipherDec = Cipher.getInstance("DES");
            SecureRandom randDec = new SecureRandom();
            cipherDec.init(Cipher.DECRYPT_MODE, key, randDec);
        } catch (Exception e) {
        	throw new RuntimeException("Cannot init security", e);
        }
    }

    public byte[] encrypt(byte[] inbytes) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        if (inbytes == null)
            return new byte[0];
    
        byte[] ret = cipherEnc.doFinal(inbytes);
        return ret;
    }

    public byte[] decrypt(byte[] inbytes) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        if (inbytes == null)
        	return new byte[0];
       
        byte[] ret = cipherDec.doFinal(inbytes);
        return ret;
    }
}
