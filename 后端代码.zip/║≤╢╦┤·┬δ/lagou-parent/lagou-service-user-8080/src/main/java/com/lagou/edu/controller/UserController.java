package com.lagou.edu.controller;

import com.lagou.edu.common.response.RespResult;
import com.lagou.edu.entity.Token;
import com.lagou.edu.remoteClient.CodeFeignClient;
import com.lagou.edu.service.UserService;
import com.lagou.edu.utils.RandomUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 用户controller
 */
@Slf4j
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private CodeFeignClient codeFeignClient;
    /**
     * 用户注册
     * @param email
     * @param password
     * @param code
     * @return
     */
    @GetMapping("/register/{email}/{password}/{code}")
    public RespResult register(@PathVariable("email") String email, @PathVariable("password") String password, @PathVariable("code") String code) {
        //1.验证邮箱验证码是否正确
        RespResult respResult = codeFeignClient.validateCode(email, code);
        if(RespResult.SUCCESS != respResult.getCode()) {
            return respResult;
        }
        //2.保存用户注册邮箱和密码
        String salt = RandomUtils.getRandomSalt();
        String token = userService.generateToken(email, password, salt);
        if (token == null) {
            respResult.setCode(402);
            respResult.setMessage("处理密码错误");
            return respResult;
        }

        Token newToken = new Token();
        newToken.setEmail(email);
        newToken.setToken(token);
        newToken.setSalt(salt);
        userService.saveUser(newToken);
        return RespResult.buildRespSuccess();
    }


    /**
     * 检查是否已经注册
     * @param email
     * @return
     */
    @GetMapping("/isRegistered/{email}")
    public RespResult isRegister(@PathVariable("email") String email) {
        Boolean isExist = userService.checkExist(email);
        RespResult respResult = RespResult.buildRespSuccess();
        respResult.setData(isExist);
        return respResult;
    }


    /**
     * 用户登录
     * @param email
     * @param password
     * @return 登录邮箱
     */
    @GetMapping("/login/{email}/{password}")
    public RespResult login(@PathVariable("email") String email, @PathVariable("password") String password, HttpServletRequest request, HttpServletResponse response) {
        RespResult respResult = new RespResult();

        Token token = userService.findUserByEmail(email);
        if (token == null) {
            respResult.setCode(404);
            respResult.setMessage("用户还未注册");
            return respResult;
        }

        //检查密码是否正确
        String oldToken = userService.generateToken(email, password, token.getSalt());
        if(!token.getToken().equals(oldToken)) {
            respResult.setCode(401);
            respResult.setMessage("用户密码错误");
            return respResult;
        }



        //保存新的token
        String newSalt = RandomUtils.getRandomSalt();
        String newToken = userService.generateToken(email, password, newSalt);
        token.setToken(newToken);
        token.setSalt(newSalt);
        userService.saveUser(token);

        HttpSession httpSession = request.getSession();
        httpSession.setAttribute("sessionId", newToken);
        httpSession.setMaxInactiveInterval(30 * 60);
        //Cookie cookie = new Cookie("sessionId", newToken);
        //cookie.setMaxAge(30 * 60);
        //cookie.setHttpOnly(true);
        //response.addCookie(cookie);


        respResult.setCode(0);
        respResult.setMessage("success");
        respResult.setData(email);
        return respResult;
    }


    /**
     * 根据用户登录token查询用户登录email
     * @return
     */
    @GetMapping("/info")
    public RespResult queryUserEmailBy(HttpServletRequest request) {
        /*Cookie[] cookies = request.getCookies();
        if(cookies != null) {
            log.info("cookies length:{}", cookies.length);
            if(cookies.length > 0) {
                for(Cookie cookie : cookies) {
                    log.info("cookie name:{}, cookie value:{}", cookie.getName(), cookie.getValue());
                }
            }
        }*/

        HttpSession session = request.getSession();
        String token = (String) session.getAttribute("sessionId");


        RespResult respResult = new RespResult();

        //Token userToken = userService.findUserByToken(request.getCookies()[0].getValue());
        Token userToken = userService.findUserByToken(token);
        if (userToken == null) {
            respResult.setCode(402);
            respResult.setMessage("用户还未登录或登录已失效");
            return respResult;
        }

        respResult.setCode(0);
        respResult.setMessage("success");
        respResult.setData(userToken.getEmail());
        return respResult;
    }

}
