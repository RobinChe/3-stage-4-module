package com.lagou.edu.service;

public interface AuthCodeService {

    boolean checkAuthCodeExist(String email, String code);

    /**
     * 随机生成6位验证码
     * @return
     */
    String generateEmailCode();

    Long saveAuthCode(String email, String code);

}
