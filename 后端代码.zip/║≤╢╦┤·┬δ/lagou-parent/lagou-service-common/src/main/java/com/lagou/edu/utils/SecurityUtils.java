package com.lagou.edu.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.codec.digest.DigestUtils;

import java.security.MessageDigest;

public class SecurityUtils {
	
	private static final String DECRYPT_ERROR = "Decrypt error";

	private static final String ENCRYPT_ERROR = "Encrypt error";

	private static final String SHA_256 = "SHA-256";

	private static final String UTF_8 = "UTF-8";

	private static final String SALT = "$#skylar!iot";
	
	private static DES des;
	
	private static AES aes;
	
	static {
		des = new DES();
		aes = new AES();
	}
	
	private SecurityUtils() {
	}
	
	public static String encryptByMD5(String str, String key) {
		return DigestUtils.md5Hex(str+key);
	}
	
	public static String encryptByXOR(String str) {
		if (str == null) {
			return null;
		}
		if (str.length() <= 1) {
			return str;
		}
		byte[] data = StringUtils.getBytesUtf8(str);
		return encryptByXOR(data);
	}
	
	public static String decryptByXOR(String str) {
		if (str == null) {
			return null;
		}
		if (str.length() <= 1) {
			return str;
		}
		byte[] data = StringUtils.getBytesUtf8(str);
		return decryptByXOR(data);
	}
	
	public static String encryptByXOR(byte[] data) {
		for (int i = 0; i < data.length - 1; i++) {
			data[i] = (byte)(data[i] ^ data[i+1]);
		}
		return StringUtils.newStringUtf8(data);
	}

	public static String decryptByXOR(byte[] data) {
		for (int i = data.length - 2; i >= 0; i--) {
			data[i] = (byte)(data[i] ^ data[i+1]);
		}
		return StringUtils.newStringUtf8(data);
	}
	
    public static String encryptSHA256(String str) throws SecurityException {
    	if (str == null) {
    		return null;
    	}
    	str = str + SALT;
        MessageDigest messageDigest;
        String result = "";
        try {
            messageDigest = MessageDigest.getInstance(SHA_256);
            byte[] hash = messageDigest.digest(str.getBytes(UTF_8));
            result = Hex.encodeHexString(hash);
        } catch (Exception e) {
        	throw new SecurityException(ENCRYPT_ERROR,e);
        }
        return result;
    }
    
    public static String encryptByAES(String text) throws SecurityException {
    	if (text == null)
            return null;
        String encryptedText = null;
        try {
            byte[] ret = aes.encrypt(text.getBytes(UTF_8));
            encryptedText = Base64.encodeBase64String(ret);
        } catch (Exception e) {
        	throw new SecurityException(ENCRYPT_ERROR,e);
        }
        return encryptedText;
    }
    
    public static String decryptByAES(String text) throws SecurityException {
        String decryptedText = null;
        try {
            byte[] dc = Base64.decodeBase64(text);
            byte[] ret = aes.decrypt(dc);
            decryptedText = new String(ret, UTF_8);
        } catch (Exception e) {
        	throw new SecurityException(DECRYPT_ERROR,e);         
        }
        return decryptedText;
    }
    
    public static String encryptByDES(String text) throws SecurityException {
        if (text == null)
            return null;
        String encryptedText = null;
        try {
            byte[] ret = des.encrypt(text.getBytes(UTF_8));
            encryptedText = Base64.encodeBase64String(ret);
        } catch (Exception e) {
        	throw new SecurityException(ENCRYPT_ERROR,e);
        }
        return encryptedText;
    }
    
    public static String decryptByDES(String text) throws SecurityException {
        String decryptedText = null;
        try {
            byte[] dc = Base64.decodeBase64(text);
            byte[] ret = des.decrypt(dc);
            decryptedText = new String(ret, UTF_8);
        } catch (Exception e) {
        	throw new SecurityException(DECRYPT_ERROR,e);         
        }
        return decryptedText;
    }
}
