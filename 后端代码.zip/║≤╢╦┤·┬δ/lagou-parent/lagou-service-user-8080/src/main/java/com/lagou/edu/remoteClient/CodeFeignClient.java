package com.lagou.edu.remoteClient;

import com.lagou.edu.common.response.RespResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "lagou-server-code", path = "/code")
public interface CodeFeignClient {


    @RequestMapping(value = "/create/{email}", method = RequestMethod.GET)
    public RespResult generateAndSendCode(@PathVariable("email") String email);


    @RequestMapping(value = "/validate/{email}/{code}", method = RequestMethod.GET)
    public RespResult validateCode(@PathVariable("email") String email, @PathVariable("code") String code);


}
