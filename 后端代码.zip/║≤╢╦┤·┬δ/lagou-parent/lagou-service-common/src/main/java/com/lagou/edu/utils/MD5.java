package com.lagou.edu.utils;

import org.springframework.util.DigestUtils;

public class MD5 {

    public static String getMD5(String str) throws Exception {
        return DigestUtils.md5DigestAsHex(str.getBytes("UTF-8"));
    }
}
