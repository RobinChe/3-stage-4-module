package com.lagou.edu.common.response;

import lombok.Data;

@Data
public class RespResult<T> {

    public static final Integer SUCCESS = 0;

    private int code;
    private String message;
    private T data;

    public static RespResult buildRespSuccess() {
        RespResult respResult = new RespResult();
        respResult.setCode(SUCCESS);
        respResult.setMessage("success");
        return respResult;
    }
}
