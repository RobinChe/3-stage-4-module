package com.lagou.edu.dao;

import com.lagou.edu.entity.Token;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<Token, Long> {

    @Query(value = "select * from lagou_token where email = ?1 order by id desc limit 1", nativeQuery = true)
    Token findByEmail(String email);
}
