package com.lagou.edu.test.service;

import com.lagou.edu.LagouServiceEmailApplication8082;
import com.lagou.edu.service.SendMailUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = LagouServiceEmailApplication8082.class)
public class SendEmailTest {

    @Autowired
    private SendMailUtils sendMailUtils;

    @Test
    public void sendEmailTest() {
        sendMailUtils.sendSimpleMailMessge("949285946@qq.com","测试邮件", "您的验证码为：123456，10分钟内有效！");
    }
}
