package com.lagou.edu.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Slf4j
public class RegisterFilter implements GatewayFilter, Ordered {

    private static final String REGISTER_URL = "/user/register/";

    //存储每个ip请求的时间
    private static ConcurrentHashMap<String, List<Long>> urlRequestTimeMap = new ConcurrentHashMap<>();

    //有效时间1分钟
    private static long REGISTER_IP_EXPIRE_TIME = 60 * 1000l;
    //最大请求为不能超过2个，  1分钟内注册请求只能2次
    private static int ALLOW_MAX_REQUEST_TIME = 2;


    static {
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        executorService.scheduleWithFixedDelay(new RemoveExpireService(), 60, 10, TimeUnit.SECONDS);
    }




    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();
        log.info("enter RegisterFilter.....");

        String clientIp = request.getRemoteAddress().getHostString();
        String path = request.getURI().getPath();
        log.info("请求的ip为：{}, 请求路径为：{}", clientIp, path);

        boolean isRegisterMore = false;
        if(path.startsWith(REGISTER_URL)) {
            List<Long> requestTimes = urlRequestTimeMap.get(clientIp);
            if (requestTimes != null) {
                int count = 0;
                for(Long time : requestTimes) {
                    if (time + REGISTER_IP_EXPIRE_TIME >= System.currentTimeMillis()) {
                        count++;
                    }
                    if (count >= ALLOW_MAX_REQUEST_TIME) {
                        isRegisterMore = true;
                        break;
                    }
                }
                //没有超过最大注册数，则保留
                if(!isRegisterMore) {
                    requestTimes.add(System.currentTimeMillis());
                    urlRequestTimeMap.put(clientIp, requestTimes);
                }
            } else {
                requestTimes = new ArrayList<>();
                requestTimes.add(System.currentTimeMillis());
                urlRequestTimeMap.put(clientIp, requestTimes);
            }
        }

        if (isRegisterMore) {
            //拒绝访问
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            String data = "register more be denied";
            DataBuffer wrap = response.bufferFactory().wrap(data.getBytes(Charset.forName("utf-8")));
            return response.writeWith(Mono.just(wrap));

        }
        return chain.filter(exchange);
    }

    @Override
    public int getOrder() {
        return 1;
    }


    static class RemoveExpireService implements Runnable {
        @Override
        public void run() {
            Iterator<Map.Entry<String, List<Long>>> iterator = urlRequestTimeMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, List<Long>> entry = iterator.next();
                List<Long> requestTimeList = entry.getValue();
                requestTimeList = removeExpireRequestTime(requestTimeList);
                if(requestTimeList.size() == 0) {
                    iterator.remove();
                } else {
                    entry.setValue(requestTimeList);
                }
            }
        }

        private List<Long> removeExpireRequestTime(List<Long> requestTimeList) {
            Iterator<Long> iterator = requestTimeList.iterator();
            while (iterator.hasNext()) {
                Long requestTime = iterator.next();
                if(requestTime + REGISTER_IP_EXPIRE_TIME >= System.currentTimeMillis()) {
                    iterator.remove();
                }
            }
            return requestTimeList;
        }



    }
}
