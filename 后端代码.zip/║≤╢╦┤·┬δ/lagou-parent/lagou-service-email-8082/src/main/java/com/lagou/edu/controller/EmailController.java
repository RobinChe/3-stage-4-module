package com.lagou.edu.controller;


import com.lagou.edu.common.response.RespResult;
import com.lagou.edu.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @GetMapping("/{email}/{code}")
    public RespResult<?> sendEmail(@PathVariable("email") String email, @PathVariable("code") String code) {
        String message = "您的验证码为：" + code + ", 5分钟内有效！";
        emailService.sendEmail(email, message);
        return RespResult.buildRespSuccess();
    }
}
