package com.lagou.edu.dao;

import com.lagou.edu.entity.AuthCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AuthCodeRepository extends JpaRepository<AuthCode, Long> {


    @Query(value = "SELECT COUNT(0) FROM lagou_auth_code WHERE email=?1 AND code=?2 AND expiretime >= NOW()", nativeQuery = true)
    public int findCodeIsExist(String email, String code);
}
