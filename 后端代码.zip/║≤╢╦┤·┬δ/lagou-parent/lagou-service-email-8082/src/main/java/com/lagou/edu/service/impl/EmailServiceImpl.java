package com.lagou.edu.service.impl;

import com.lagou.edu.service.EmailService;
import com.lagou.edu.service.SendMailUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private SendMailUtils sendMailUtils;

    @Override
    public void sendEmail(String email, String message) {
        sendMailUtils.sendMimeMessge(email, "测试的验证码标题", message);
    }
}
