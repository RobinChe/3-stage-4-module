package com.lagou.edu.utils;

import java.util.Random;

public class RandomUtils {

    public static String getRandomSalt() {
        int flag = new Random().nextInt(999999);
        if (flag < 100000)
        {
            flag += 100000;
        }
        return String.valueOf(flag);
    }

    public static void main(String[] args) {
        System.out.println(getRandomSalt());
    }
}
