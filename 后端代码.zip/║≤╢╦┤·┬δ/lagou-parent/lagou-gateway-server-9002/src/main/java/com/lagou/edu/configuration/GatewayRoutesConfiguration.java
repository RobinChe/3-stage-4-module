package com.lagou.edu.configuration;

import com.lagou.edu.filter.RegisterFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class GatewayRoutesConfiguration {

    @Bean
    public RouteLocator routeLocator(RouteLocatorBuilder builder) {
        log.info("UserServiceGatewayFilter filter........");
        return builder.routes()
                .route(r ->
                        r.path("/api/user/**")
                                .filters(
                                        f -> f.stripPrefix(1)
                                                .filters(new RegisterFilter())
                                )
                                .uri("lb://lagou-server-user")
                )
                .build();
    }
}
